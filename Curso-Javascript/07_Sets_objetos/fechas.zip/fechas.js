const fechaHoy = new Date();

const fechaNacimiento = new Date(1998, 5, 10);

const conpara = (fechaHoy > fechaNacimiento)

const dianacimiento = fechaNacimiento.getDate()
const mesNacimiento = fechaNacimiento.getMonth() + 1;
const anioNacimiento = fechaNacimiento.getFullYear();

