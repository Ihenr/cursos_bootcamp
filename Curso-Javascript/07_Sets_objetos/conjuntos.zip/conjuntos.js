const nombreFamilia = ["Henry","Javier","Jonatan","Evelin","Angie","Mesedes","Wilfrido"]
const setfamilia = new Set(nombreFamilia);
setfamilia.add("Henry");
setfamilia.add("JavaScript");
console.log(setfamilia)