const lista = [
    "Henry",
    24,
    true,
    new Date(1998, 6, 10),
    libro={ 
        titulo: "Psicología Oscura ",
        autor: "R. J. Anderson",
        fecha: new Date(2020, 7, 14),
        url:"https://www.audible.com/pd/Psicologia-Oscura-Dark-Psychology-Audiobook."
    },
];


console.log(lista)