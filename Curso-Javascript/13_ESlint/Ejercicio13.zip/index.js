let nombre = "Henry";
let apellido = "Morocho";

let estudiante = nombre.concat(" ", apellido);
let estudianteMayus = estudiante.toUpperCase();
let estudianteMinus = estudiante.toLowerCase();
let estulength = estudiante.length;
let inicialNom = nombre.charAt(0);
let finalApe = apellido.charAt(apellido.length -1);
let eliminarEspa = estudiante.replace(/ /g, "");
let nombrecontenido = estudiante.includes(nombre);