//Factorial While
let i = 1;
let factorial = 1;

while(i <= 10){
    console.log(i);
    factorial *= i;
    i++;
}

console.log(factorial);