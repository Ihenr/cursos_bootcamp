const listaCompra = ["Arroz", "Huevos", "Limones","Manzanas","Peras"];

listaCompra.push("Aceite de Girasol");
listaCompra.pop()

const peliculas = [
    {
        titulo: "Black Adam",
        director: "Jaume Collet",
        fecha: new Date(2022, 10, 29)
    },
    {
        titulo: "Spider-Man: No Way Home",
        director: "Jon Watts",
        fecha: new Date(2021, 11, 16)
    },
    {
        titulo: "Avatar",
        director: "James Cameron",
        fecha: new Date(2009, 10, 29)
    }
];

const peliculaNueva = peliculas.filter(pelicula => pelicula.fecha > new Date(2010, 0, 1))

const directores = peliculas.map(director => director.director)

const titulos = peliculas.map(titulo => titulo.titulo)

const concatenar = directores.concat(titulos)

const propagacion = [...directores, ...titulos];
console.log(propagacion);
