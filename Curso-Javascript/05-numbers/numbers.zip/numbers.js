const altura_cm = 170;
const altura_m = 1.70;
const peso_kg = 78.9;

const altura_redondeo = Math.ceil(altura_m);
const peso_redondeo = Math.floor(peso_kg);

const igual_js = (Number.MAX_VALUE + 1) === (Number.MAX_VALUE);
console.log(igual_js)