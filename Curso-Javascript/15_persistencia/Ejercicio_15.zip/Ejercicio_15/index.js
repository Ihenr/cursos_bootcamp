const nombre = "Henry"
const apellido = "Morocho"
const datos = {nombre, apellido}


// sessionStorage.getItem("datos", JSON.stringify(datos))
// localStorage.setItem("datos", JSON.stringify(datos))

// document.cookie = "datos=${JSON.stringify(datos)};expires" + new Date(now.getTime() + 2 * 60000).toUTCString()