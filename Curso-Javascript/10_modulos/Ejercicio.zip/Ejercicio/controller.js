export function suma(a, b) {
    return a + b;
}

export function multiplicacion(a, b ) {
    return a * b;
}